library(readxl)
library(dplyr)
library(lubridate)


# Carregar a base de dados
df <- read_excel("C:/Sao Judas/2023-1/A3/divisao1cloridato.xlsx")






################################## HIPÓTESE 1 #######################################



# Converter a coluna 'MÊS_VENDA' para o tipo data e extrair o mês
df$MÊS_VENDA <- as.Date(df$MÊS_VENDA, format = "%Y-%m-%d")
df$MÊS <- month(df$MÊS_VENDA)

# Definir a função para as estações do ano
definir_estacao <- function(mes) {
  ifelse(mes %in% c(9, 10, 11), "Primavera",
         ifelse(mes %in% c(12, 1, 2), "Verão",
                ifelse(mes %in% c(3, 4, 5), "Outono",
                       ifelse(mes %in% c(6, 7, 8), "Inverno", NA)
                )
         )
  )
}


vendas_por_mes <- table(month(df$MÊS))

media_vendas <- mean(vendas_por_mes)

num_amostra = 3
vendas_amostra_inverno <- vendas_por_mes[c(6, 7, 8)]

media_inverno <- mean(vendas_amostra_inverno)
desvio_padrao_inverno <- sd(vendas_amostra_inverno)


#Hipótese nula (H0): As vendas de médicamentos no inverno é maior ou igual ao restante do ano. H0 <= 3256
#Hipótese alternativa (Ha): As vendas de médicamentos é maior durante o inverno. Ha > 3256

#
gl = num_amostra - 1

# Calcular a estatística do teste t
teste_t <- (media_inverno - media_vendas) / (desvio_padrao_inverno / sqrt(num_amostra))
print(paste("Estatística t:", teste_t))

# Calcular o valor t crítico para um teste unilateral a direita
t_critico <- (qt(0.05, gl)) * -1
print(paste("Valor t crítico:", t_critico))

# Resposta

# t não pertence a região crítica logo aceitamos a hipotese nula




################################## HIPÓTESE 2 #######################################

# Carregar a base de dados
df_municipios <- read_excel("C:/Sao Judas/2023-1/A3/Tipologia_municipal_rural_urbano.xlsx", sheet="Tipologia_munic_rural_urbano")

# Padronizar o nome do município em ambas as planilhas (opcional)
df$MUNICIPIO_VENDA <- toupper(df$MUNICIPIO_VENDA)
df_municipios$NM_MUN <- toupper(df_municipios$NM_MUN)

# Unir as duas planilhas pela coluna do nome do município
vendas_com_tipo_municipio <- merge(df, df_municipios, by.x = "MUNICIPIO_VENDA", by.y = "NM_MUN")

# Contar o número de vendas de medicamentos em cada município
vendas_por_municipio <- table(vendas_com_tipo_municipio$MUNICIPIO_VENDA)

# Obter a lista de municípios urbanos
municipios_urbanos <- unique(vendas_com_tipo_municipio$MUNICIPIO_VENDA[vendas_com_tipo_municipio$TIPO == "Urbano"])

# Obter o número de vendas de medicamentos em municípios urbanos e em todos os municípios
vendas_urbanos <- vendas_por_municipio[municipios_urbanos]
vendas_todos <- vendas_por_municipio

# Calcular a média e o desvio padrão do número de vendas
media_urbanos <- mean(vendas_urbanos)
desvio_padrao_urbanos <- sd(vendas_urbanos)
media_todos <- mean(vendas_todos)

# Hipótese nula (H0): O número médio de vendas de medicamentos em municípios urbanos é igual ou menor do que o número médio de vendas em todos os municípios. 
# Hipótese alternativa (Ha): O número médio de vendas de medicamentos em municípios urbanos é maior do que o número médio de vendas em todos os municípios.

# Número de municípios urbanos
n <- length(vendas_urbanos)

# Graus de liberdade
gl <- n - 1

# Calcular a estatística do teste t
teste_t <- (media_urbanos - media_todos) / (desvio_padrao_urbanos / sqrt(n))
print(paste("Estatística t:", teste_t))

# Calcular o valor t crítico para um teste unilateral à direita
t_critico <- (qt(0.05, gl)) * -1
print(paste("Valor t crítico:", t_critico))

# Resposta

# t não pertence a região crítica logo aceitamos a hipotese nula
