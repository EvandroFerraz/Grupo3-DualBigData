# ANALISE DESCRITIVA

# INTEGRANTES DO GRUPO

# Caique Andrade dos Santos       RA: 823121611
# Gabriel Marques Celentano       RA: 82117863
# Ginaldo Dos Santos Silva        RA: 821137130
# Guilherme Angelus Felix Araujo  RA: 821132145
# Jacqueline Vigilat Silva        RA: 819226277
# Pedro Henrique Rezende Oliveira RA: 820279207


# 1 - Explicar o conjunto de dados

# Os dados que constituem a nossa base de dados são um recorte da base de dados "Brazilian sales of controlled drugs by ANVISA" (ACARDOSO, 2023),
# recorte este, referente aos anos 2000 e 2021, e ao medicamento "Cloridrato de Nortriptilina"


# 2 - Explicar as variáveis

# DICIONARIO DE DADOS

# ID : id da compra

# Principio_Ativo : Medicamento Cloridrato de Nortriptilina

# DCB : Código do medicamento da base original

# ANO_VENDA : Ano da venda do medicamento

# DATA_VENDA : Data da venda do medicamento

# DATA_VENCIMENTO : Data de vencimento do medicamento

# SEXO :  Sexo do paciente para quem o medicamento era destinado (aplicável apenas a medicamentos antimicrobianos). 
# Valor 1 para o sexo masculino,
# valor 2 para o sexo feminino.

# IDADE: Idade dos pacientes

# UF_VENDA : Unidade Federativa do Conselho de Classe do profissional que prescreveu o medicamento vendido

# MUNICIPIO_VENDA : Município do endereço da farmácia ou drogaria, cadastrado no banco de dados da Anvisa, representando o Município onde ocorreu a venda.

# QTD_UNIDADE_FARMACOTECNICA :  Quantidade de unidades farmacotécnicas vendidas

# TIPO_RECEITUARIO : Tipo de receituário utilizado na prescrição 
# 1 – Receita de Controle Especial em 2 vias (Receita Branca);
# 2 – Notificação de Receita B (Notificação Azul); 
# 3 – Notificação de Receita Especial (Notificação Branca);
# 4 – Notificação de Receita A (Notificação Amarela); 
# 5 – Receita Antimicrobiano em 2 vias.

# Abaixo começa o código

install.packages("readxl")
library(readr)
library("readxl")

rm(list = ls())

# mudando o endereco da pasta raiz do r para onde está o arquivo
setwd("caminho")

# nome do arquivo: divisao1cloridato (1).xlsx

# Ler o conjunto de dados
df <- read_excel("caminho/divisao1cloridato (1).xlsx")

# Visualizar as primeiras linhas do dataset
head(df)

# Visualizar as últimas linhas do dataset
tail(df)


# 3 - Descrever cada variável e fazer as tabelas de frequencia e medidas de posicao-dispersao 

# Verificar a estrutura do dataframe
str(df)


# variaveis quantitativas discretas

# ANO_VENDA 
# IDADE
# QTD_UNIDADE_FARMACOTECNICA


# variaveis quantitativas continuas
# IDADE
# DATA_VENDA
# DATA_VENCIMENTO

# Estatísticas descritivas das variáveis quantitativas
summary(df$ANO_VENDA)
summary(df$IDADE)
summary(df$QTD_UNIDADE_FARMACOTECNICA)
summary(df$DATA_VENDA)
summary(df$DATA_VENCIMENTO)


# variaveis qualitativas ordinais
# SEXO
# TIPO_RECEITUARIO

# variaveis qualitativas nominais
# UF_VENDA
# MUNICIPIO_VENDA 

# Tabela de frequência das variáveis qualitativas
table(df$SEXO)
table(df$UF_VENDA)
table(df$MUNICIPIO_VENDA)
table(df$TIPO_RECEITUARIO)

# 4 - Verificar as relações entre variáveis
# criar um conjunto somente com as variáveis quantitativas

df_quantitativas <- df[, c( "ANO_VENDA ", "IDADE", "QTD_UNIDADE_FARMACOTECNICA", "DATA_VENDA"), "DATA_VENCIMENTO"]

# fazer a matriz de correlação
cor(df_quantitativas)


# Comentários 

# Mais da metade do conjunto dos registros das pessoas que compraram o medicamento tem 0 anos de idade.

# Proporção praticamente equilibrada de compras entre homens e mulheres, com leve vantagem para o homens.

# Os estados que tiveram o maior consumo durante o  bienio 2020/2021 foram SP (estado mais populoso do Brasil), seguido por GO, PR, MG e RN.
# Os estados que tiveram o menor consumo foram PB, RS, AP,AC e SE
# Alguns estados não apareceram: MA,PI,RR,TO
# Estados com menor consumo ou que não apareceram estão entre os menos populosos do Brasil.






