library(readxl)
library(dplyr)
library(lubridate)
library(ggplot2)


# Carregar a base de dados
df <- read_excel("C:/Sao Judas/2023-1/A3/divisao1cloridato.xlsx")






################################## HIPÓTESE 1 #######################################

# Converter a coluna 'MÊS_VENDA' para o tipo data e extrair o mês
df$MÊS_VENDA <- as.Date(df$MÊS_VENDA, format = "%Y-%m-%d")
df$MÊS <- month(df$MÊS_VENDA)

# Definir a função para as estações do ano
definir_estacao <- function(mes) {
  ifelse(mes %in% c(9, 10, 11), "Primavera",
         ifelse(mes %in% c(12, 1, 2), "Verão",
                ifelse(mes %in% c(3, 4, 5), "Outono",
                       ifelse(mes %in% c(6, 7, 8), "Inverno", NA)
                )
         )
  )
}

df <- df %>%
  mutate(Estacao = definir_estacao(MÊS))

df %>%
  group_by(MÊS, Estacao) %>%
  summarise(Vendas = n()) %>%
  ggplot(aes(x = MÊS, y = Vendas, fill = Estacao)) +
  geom_col() +
  scale_fill_manual(values = c("Inverno" = "blue", "Outono" = "brown", "Primavera" = "green", "Verão" = "yellow")) +
  labs(x = "Mês", y = "Total de Vendas", fill = "Estação", 
       title = "Vendas de medicamentos por mês e estação do ano")

vendas_por_mes <- table(month(df$MÊS))

media_vendas <- mean(vendas_por_mes)

num_amostra_hip1 = 3
vendas_amostra_inverno <- vendas_por_mes[c(6, 7, 8)]

media_inverno <- mean(vendas_amostra_inverno)
desvio_padrao_inverno <- sd(vendas_amostra_inverno)


#Hipótese nula (H0): As vendas de médicamentos no inverno é maior ou igual ao restante do ano. H0 <= 3256
#Hipótese alternativa (Ha): As vendas de médicamentos é maior durante o inverno. Ha > 3256

gl_hip1 = num_amostra_hip1 - 1

# Calcular a estatística do teste t
teste_t_hip1 <- (media_inverno - media_vendas) / (desvio_padrao_inverno / sqrt(num_amostra_hip1))
print(paste("Estatística t:", teste_t_hip1))

# Calcular o valor t crítico para um teste unilateral a direita
t_critico_hip1 <- (qt(0.05, gl_hip1)) * -1
print(paste("Valor t crítico:", t_critico_hip1))

# Variáveis exemplo (substitua pelas suas próprias variáveis)
valor_t_hip1 <- teste_t_hip1

# Criar sequência de x para plotar a curva t
x <- seq(-4, 4, length = 1000)
# Densidade da distribuição t
y <- dt(x, df = gl_hip1)

# Criar data frame para plotagem
df <- data.frame(x = x, y = y)

# Gráfico
ggplot(df, aes(x = x, y = y)) +
  geom_line() +
  geom_vline(aes(xintercept = valor_t_hip1), linetype = "dashed", color = "blue") +
  geom_vline(aes(xintercept = t_critico_hip1), linetype = "dashed", color = "red") +
  annotate("text", x = valor_t_hip1, y = max(y) * 0.85, label = "Valor t", color = "blue", hjust = "left") +
  annotate("text", x = t_critico_hip1, y = max(y) * 0.75, label = "t crítico", color = "red", hjust = "left") +
  theme_minimal() +
  labs(x = "Valor t", y = "Densidade", title = "Hipótese 1 - Distribuição t")

# Resposta

# t não pertence a região crítica logo aceitamos a hipotese nula




################################## HIPÓTESE 2 #######################################

# Agrupar por município e somar as vendas
df_agregado <- df %>%
  group_by(MUNICIPIO_VENDA) %>%
  summarise(VENDAS = n())

# Carregar a base de dados
df_municipios <- read_excel("C:/Sao Judas/2023-1/A3/Tipologia_municipal_rural_urbano.xlsx", sheet="Tipologia_munic_rural_urbano")

df_municipios <- df_municipios %>%
  mutate(TIPO = if_else(TIPO %in% c("RuralAdjacente", "RuralRemoto"), "Rural", "Urbano"))

# Carregar a base de dados
df_municipios_populacao <- read_excel("C:/Sao Judas/2023-1/A3/Populacao_total_em_mancha_de_ocupacao_densa.xlsx", sheet="Pop_total_mancha_ocup_densa")

# Unir populacao e tipologia
df_municipios_pop <- merge(df_municipios, df_municipios_populacao, by.x = "CD_GCMUN", by.y = "CD_GCMUN")

# Padronizar o nome do município em ambas as planilhas (opcional)
df_agregado$MUNICIPIO_VENDA <- toupper(df_agregado$MUNICIPIO_VENDA)
df_municipios_pop$NM_MUN <- toupper(df_municipios_pop$NM_MUN.x)

# Unir as duas planilhas pela coluna do nome do município
vendas_municipio <- merge(df_agregado, df_municipios_pop, by.x = "MUNICIPIO_VENDA", by.y = "NM_MUN")

# Calcular vendas per capita para cada município
vendas_municipio$VENDAS_PER_CAPITA <- vendas_municipio$VENDAS / vendas_municipio$POP_TOTAL_UNID_POP

# Calcular a média e o desvio padrão das vendas per capita
media_per_capita_urbanos <- mean(vendas_municipio$VENDAS_PER_CAPITA[vendas_municipio$TIPO == "Urbano"])
desvio_padrao_per_capita_urbanos <- sd(vendas_municipio$VENDAS_PER_CAPITA[vendas_municipio$TIPO == "Urbano"])
media_per_capita_todos <- mean(vendas_municipio$VENDAS_PER_CAPITA)

# Hipótese nula (H0): O número médio per capita de vendas de medicamentos em municípios urbanos é igual ou menor do que o número médio per capita de vendas em todos os municípios. 
# Hipótese alternativa (Ha): O número médio per capita de vendas de medicamentos em municípios urbanos é maior do que o número médio per capita de vendas em todos os municípios.

# Número de municípios urbanos
n <- sum(vendas_municipio$TIPO == "Urbano")

# Graus de liberdade
gl <- n - 1

# Calcular a estatística do teste t
teste_t <- (media_per_capita_urbanos - media_per_capita_todos) / (desvio_padrao_per_capita_urbanos / sqrt(n))
print(paste("Estatística t:", teste_t))

# Calcular o valor t crítico para um teste unilateral à direita
t_critico <- (qt(0.05, gl)) * -1
print(paste("Valor t crítico:", t_critico))

# Variáveis exemplo (substitua pelas suas próprias variáveis)
valor_t_hip2 <- teste_t

# Criar sequência de x para plotar a curva t
x <- seq(-4, 4, length = 1000)
# Densidade da distribuição t
y <- dt(x, df = gl)

# Criar data frame para plotagem
df <- data.frame(x = x, y = y)

# Gráfico
ggplot(df, aes(x = x, y = y)) +
  geom_line() +
  geom_vline(aes(xintercept = valor_t_hip2), linetype = "dashed", color = "blue") +
  geom_vline(aes(xintercept = t_critico), linetype = "dashed", color = "red") +
  annotate("text", x = valor_t_hip2, y = max(y) * 0.85, label = "Valor t", color = "blue", hjust = "left") +
  annotate("text", x = t_critico, y = max(y) * 0.75, label = "t crítico", color = "red", hjust = "left") +
  theme_minimal() +
  labs(x = "Valor t", y = "Densidade", title = "Hipótese 2 - Distribuição t")


df_grafico_hip2 <- df_reduzido %>% 
  group_by(TIPO) %>%
  summarise(VENDAS_PER_CAPITA = sum(VENDAS_PER_CAPITA))

# Criando o gráfico
ggplot(df_grafico_hip2, aes(x = TIPO, y = VENDAS_PER_CAPITA, fill = TIPO)) +
  geom_col() +
  scale_fill_manual(values = c("Urbano" = "blue", "Rural" = "green")) +
  labs(x = "Tipo de Município", y = "Vendas per capita", fill = "Tipo de Município", 
       title = "Vendas per capita de medicamentos por tipo de município")


# Resposta
#"Estatística t: -6.86605523023917"
#"Valor t crítico: 1.65304288894663"

# t não pertence a região crítica logo aceitamos a hipotese nula
